#!/bin/sh
################################################################################
# This file contains u-boot environment fixes                                  #
################################################################################

##### Functions

set_if_changed() {
    tmp=`fw_printenv -n "$1" 2>/dev/null`
    if [ "$tmp" != "$2" ]; then
		fw_setenv "$1" "$2"
		need_reboot=1
		need_reset_firmware=1
		echo "Replacing value of u-boot env variable $1"
		echo "   before : $tmp"
		echo "   after  : $2"
    fi
}

#
# Handle invalid/unitialiased environment
#
do_init_fw_env()
{
    fw_printenv > /dev/null 2>&1
    local ENV_VALID=$?

    if [ "${ENV_VALID}" != "0" ]; then
        echo Initializing environment ...
        fw_setenv --clear-env
    fi
}

#
# Initialize fw_env MAC-address
#
do_init_fw_env_mac()
{
    MACADDR=$( fw_printenv -n "ethaddr" )
    if [ -z "$MACADDR" ]; then
        MACADDR=$( /sbin/stbvendor --mac )
        if [ "$?" == "0" -a -n "$MACADDR" ]; then
            fw_setenv "ethaddr" "$MACADDR"
            echo "Saving MAC address $MACADDR to u-boot env ..."
        fi
    fi
}

#
# Initialize fw_env serial#
#
do_init_fw_env_serial()
{
    SERIAL=$( fw_printenv -n "serial#" )
    if [ -z "$SERIAL" ]; then
        SERIAL=$( /sbin/stbvendor --serial )
        if [ "$?" == "0" -a -n "$SERIAL" ]; then
            fw_setenv "serial#" "$SERIAL"
            echo "Saving serial number $SERIAL to u-boot env ..."
        fi
    fi
}

#
# Perform uboot checks
#
do_uboot_checks()
{
    #
    # Check u-boot env variable "setbootargs"
    #
    if [ "${DEVICEID}" == "sml7105" ]; then
        default_setbootargs="setenv bootargs \"sml7105_serial=\${serial#}\""
    else
        default_setbootargs="setenv bootargs \"\""
    fi
    setbootargs=`fw_printenv -n "setbootargs"`

    if [ "$setbootargs" != "$default_setbootargs" ]; then
        echo "Resetting \"setbootargs\" u-boot variable ..."
        fw_setenv setbootargs "$default_setbootargs"
        need_reboot=1
        need_reset_firmware=1
    fi

    #
    # Check u-boot env variable "bootargs"
    #
    default_bootargs="console=ttyAS0,115200"
    bootargs=`fw_printenv -n "bootargs"`
    if [ "$bootargs" != "$default_bootargs" ]; then
        echo "Resetting \"bootargs\" u-boot variable ..."
        fw_setenv bootargs "$default_bootargs"
        need_reboot=1
        need_reset_firmware=1
    fi
}

##### Entry point

. /etc/init.d/init-functions

get_deviceid

echo "Quirks BEGIN BOARD:${DEVICEID}-------------------------------------------------------------"

need_reboot=0
need_reset_firmware=0

# Reset deprecated NVRAM vars (does nothing if no such vars)
fw_setenv verify_rootfs

if [ "${DEVICEID}" == "vip19x3" ]; then

#
# Handle factory reset & invalid/unitialiased environment
#
	fw_printenv > /dev/null 2>&1
	ENV_VALID=$?

	if [ "${VIP_FACTORY_RESET}" == "Set" ]; then
		echo Appling factory reset ...
	elif [ ${ENV_VALID} != 0 ]; then
		echo Initializing environment ...
	fi

	# Preserve important variable values
	# if factory_reset & env_valid (i.e. has values)
	if [ ${ENV_VALID} == 0 -a "${VIP_FACTORY_RESET}" == "Set" ]; then
		# MAC    - don't, to restore factory value
		# serial - don't, to restore factory value
		# layout - store to preserve persistentfs from format
		# fw_ver - store to preserve from upgrade
		# bi_changed - store to prevent fw version skew
		# bi_md5 - store to prevent fw version skew
		STORED_LAYOUT=$( fw_printenv -n "partitions_layout" )
		STORED_FW_VERSION=$( fw_printenv -n "firmware_version" )
		STORED_BI_CHANGED=$( fw_printenv -n "bootimage_changed" )
		STORED_BI_MD5=$( fw_printenv -n "bootimage_md5" )
	fi

	# Clean/initialize environment
	if [ ${ENV_VALID} != 0 -o "${VIP_FACTORY_RESET}" == "Set" ]; then
		fw_setenv --clear-env
	fi

	# Restore variable values
	if [ ${ENV_VALID} == 0 -a "${VIP_FACTORY_RESET}" == "Set" ]; then
		fw_setenv partitions_layout ${STORED_LAYOUT}
		fw_setenv firmware_version  ${STORED_FW_VERSION}
		fw_setenv bootimage_changed ${STORED_BI_CHANGED}
		fw_setenv bootimage_md5     ${STORED_BI_MD5}

		# pass reset command to application
		fw_setenv do_factory_reset 1
	fi

	# Reset factory flag
	if [ "${VIP_FACTORY_RESET}" == "Set" ]; then
		cd /
		${KINFO} --clear-factory-reset-flag
	fi

#
# Initialize fw_env MAC-address
#
	MACADDR=`fw_printenv -n "ethaddr"`

	if [ -z "${MACADDR}" ] ; then
		MACADDR=${VIP_MAC1}
		echo "Got MAC-address '${MACADDR}'"

	# ignore empty or moto stub
		if [ -z "${MACADDR}" -o "${MACADDR}" == "00:02:9B:BE:BE:BE" ]; then
			echo "fallling to deprecated method"
			MACADDR=$(cat /sys/class/net/eth0/address)
		fi

		fw_setenv ethaddr ${MACADDR}
	fi

#
# Initialize fw_env STB serial number
#
	SERIAL=$( fw_printenv -n "serial#" )

	if [ -z "${SERIAL}" ] ; then
		SERIAL=${VIP_SERIAL}
		echo "Got serial No '${SERIAL}'"

		if [ -z "${SERIAL}" ]; then
			echo "fallling to deprecated method"
			SERIAL="SN"$(echo -n ${MACADDR} | tr -d ":" | tr '[a-f]' '[A-F]')
		fi

		fw_setenv "serial#" ${SERIAL}
	fi

#
# Force kernel cmdline network settings on inherit_boot_ip set
#
	INHERIT_BOOT_IP=$(fw_printenv -n inherit_boot_ip)

	if [ -n "${INHERIT_BOOT_IP}" ]; then

		echo kernel cmdline:
		cat /proc/cmdline

		DHCP=$(cat /proc/cmdline | tr " " "\n" | tr "=" " " | grep "^serverid")

		FW_ETH_MODE=$(fw_printenv -n eth0_mode)

		echo    "Previous IP mode is ... '${FW_ETH_MODE}'"
		echo -n "Detected IP mode is ... "

		if [ -z "${DHCP}" ]; then
			echo "manual"

			IPARGS=$(cat /proc/cmdline | tr " " "\n" | tr "=" " " | grep "^ip" | awk '{ print $2 }' | tr ":" " ")
			IP_ADDR=$(echo ${IPARGS} | awk '{ print $1 }')
			IP_GATE=$(echo ${IPARGS} | awk '{ print $2 }')
			IP_MASK=$(echo ${IPARGS} | awk '{ print $3 }')

			echo "parsed IP: '${IP_ADDR}' Mask: '${IP_MASK}' Gate: '${IP_GATE}'"

			if [ "${FW_ETH_MODE}" != "manual" ]; then
				echo forcing manual mode
				fw_setenv eth0_mode manual
			fi

			FW_IP_ADDR=$(fw_printenv -n eth0_ip)
			FW_IP_MASK=$(fw_printenv -n eth0_netmask)
			FW_IP_GATE=$(fw_printenv -n eth0_gateway)

			echo "stored IP: '${FW_IP_ADDR}' Mask: '${FW_IP_MASK}' Gate: '${FW_IP_GATE}'"

			if [ "${FW_IP_ADDR}" != "${IP_ADDR}" ]; then
				echo storing IP
				fw_setenv eth0_ip ${IP_ADDR}
			fi

			if [ "${FW_IP_MASK}" != "${IP_MASK}" ]; then
				echo storing mask
				fw_setenv eth0_netmask ${IP_MASK}
			fi

			if [ "${FW_IP_GATE}" != "${IP_GATE}" ]; then
				echo storing gateway
				fw_setenv eth0_gateway ${IP_GATE}
			fi
		else
			echo "dhcp"

	        	if [ "${FW_ETH_MODE}" != "dhcp" ]; then
				echo forcing dhcp mode
	                	fw_setenv eth0_mode dhcp
		        fi
		fi
	fi

#
# Standby boot mode - turn STB "On" and reboot
# (workaround for correct LEDs detection)
#
	if [ "${VIP_IN_STANDBY}" == "Yes" ]; then
		echo "Booted in standby mode - need turn on and reboot"

		OLD_MODE=$( ${KINFO} --standby -n )
		${KINFO} --standby=No
		NEW_MODE=$( ${KINFO} --standby -n )

	# Ensure, that flag is really changed (to avoid reboot loop)
		if [ -n "${NEW_MODE}" -a -n "${OLD_MODE}" -a "${NEW_MODE}" != "${OLD_MODE}" ]; then
			need_reboot=1
		else
			echo "Can't turn STB On, giving up"
		fi
	fi

elif [ "${DEVICEID}" == "ps7105" ]; then
    do_init_fw_env_mac
    do_init_fw_env_serial
elif [ "${DEVICEID}" == "mag200" ]; then
    true
elif [ "${DEVICEID}" == "mag250" ]; then
    true
elif [ "${DEVICEID}" == "zyxel1001s" -o "${DEVICEID}" == "zyxel1001s2" -o "${DEVICEID}" == "zyxel1001h" ]; then
    # Move ZyXEL-1001S framebuffer because default value is used by system memory
    if [ "${DEVICEID}" == "zyxel1001s" ]; then
        set_if_changed "fb_addr" 0xA7E00000
    fi

    set_if_changed "ramfscmd" "bootm 0xA0080000; bootm 0xA0240000; dhcp; tftpboot \${load_addr}; bootm \${load_addr}"

elif [ "${DEVICEID}" == "yuxing" ]; then
    do_init_fw_env
    do_init_fw_env_mac
    do_init_fw_env_serial

#
# Initialize fw_env framebuffer phys addr
#
    FB_ADDR=$( fw_printenv -n "fb_addr" )

    if [ -z "${FB_ADDR}" ] ; then
        # fbsplash address depends on CFE build date
	    CFEV=`dd if=/dev/mtd0 skip=250 bs=1024 count=10 | grep 2011`
	    if [ "$CFEV" != "" ]; then
            FB_ADDR="0x8a800000"
	    else
	        CFEV=`dd if=/dev/mtd0 skip=250 bs=1024 count=10 | grep 2010`
	        if [ "$CFEV" != "" ]; then
                FB_ADDR="0x8c800000"
            else
                FB_ADDR="0x8a800000"
            fi
       fi
       fw_setenv "fb_addr" ${FB_ADDR}
    fi

#
# Turn off front panel clocks
#
    stty -F /dev/ttyS1 0:4:1cb1:a30:3:1c:7f:15:1:0:0:0:11:13:1a:0:12:f:17:16:4:0:0:0:0:0:0:0:0:0:0:0:0:0:0:0
    echo -e -n "\xAA\x27\x09\xC0\x00\x00\x00\x00\x00\x00\x00\x00\x66" > /dev/ttyS1
elif [ "${DEVICEID}" == "sml723x" ]; then
    do_init_fw_env
    do_init_fw_env_mac
    do_init_fw_env_serial

    # Apply ECC fix to 30K MTS order (November, 2013) and Trial order (June, 2013)
    # if ECC was enabled we should format NAND.
    # When update will be done nand_ecc_fix_step flag is setted (see init script )

    OPERATOR=`echo $SERIAL | cut -b 10`
    PRODUCTION_DATE=`echo $SERIAL | cut -b 12-15`
    if [ "$OPERATOR" == "3" -a "$PRODUCTION_DATE" == "1339" -o "$OPERATOR" == "0" -a "$PRODUCTION_DATE" == "1306" ]; then
        NAND_ECC_FIX_STEP=$( fw_printenv -n -q nand_ecc_fix_step )

        # Format UBI with enabled ECC if this is a first boot after upgrade
        if [ "${NAND_ECC_FIX_STEP}" == "" ]; then
            echo "Applying ECC fix for 30K nov-2013 order"

            # Writing to NVRAM _before_ formatting kernels,
            # to guarantee that firmware will be flashed one more time anyway
            fw_setenv restore_firmware 2

            need_reset_firmware=2

            RAW_MTD_NUMBER=`awk '{if ($4 ~ /\<raw\>/) print $1}' /proc/mtd | sed 's/mtd//g' | sed 's/://g'`
            echo "ECC fix: re-formatting raw mtd #${RAW_MTD_NUMBER}"
            ubiformat --yes "/dev/mtd${RAW_MTD_NUMBER}"

            BACKUP_KERNEL_MTD_NUMBER=`awk '{if ($4 ~ /\<backup_kernel\>/) print $1}' /proc/mtd | sed 's/mtd//g' | sed 's/://g'`
            echo "ECC fix: re-formatting backup_kernel mtd #${BACKUP_KERNEL_MTD_NUMBER}"
            ubiformat --yes "/dev/mtd${BACKUP_KERNEL_MTD_NUMBER}"

            KERNEL_MTD_NUMBER=`awk '{if ($4 ~ /\<kernel\>/) print $1}' /proc/mtd | sed 's/mtd//g' | sed 's/://g'`
            echo "ECC fix: re-formatting kernel mtd #${KERNEL_MTD_NUMBER}"
            ubiformat --yes "/dev/mtd${KERNEL_MTD_NUMBER}"
        else
            echo "ECC fix has already been applied"
        fi
    fi

    # Broadcom boards do not use u-boot, so disable further checks
    no_uboot_checks=1
elif [ "${DEVICEID}" == "sml7105" ]; then
    do_uboot_checks
elif [ "${DEVICEID}" == "sml7105dev" ]; then
    do_uboot_checks
fi


#
# Check partitions layout
#
# layout #0 (1.4):		64Mb rootfs
# layout #1 (>= 1.5):	96Mb rootfs, 16Mb persistentfs

partitions_layout=`fw_printenv -q -n "partitions_layout"`

# If "partitions_layout" not defined or "0" then let's switch
# to layout #1.
if [ -z "$partitions_layout" -o "$partitions_layout" == "0" ]; then
	format_persistentfs=1
fi


# mag250: do not format persistentfs until firmware is flashed
if [ "${DEVICEID}" == "mag250" -o "${DEVICEID}" == "mag200" ]; then
    firmware_version=`fw_printenv -q -n "firmware_version"`
    if [ "$firmware_version" == "" ]; then
        format_persistentfs=0
    fi
fi

# ZyXEL-1001S/S2/H: do not format persistentfs, it is formated in block-preflash.sh
if [ "${DEVICEID}" == "zyxel1001s" -o "${DEVICEID}" == "zyxel1001s2" -o "${DEVICEID}" == "zyxel1001h" ]; then
    format_persistentfs=0
fi

# Broadcom (SML-482/492 Yuxing) format persistentfs in /etc/init.d/ubi
if [ "${DEVICEID}" == "sml723x" -o "${DEVICEID}" == "yuxing" ]; then
    format_persistentfs=0
fi

if [ "$format_persistentfs" == "1" ]; then

	# Format persistentfs
	PERSISTENTFS_DEV=`awk '{if ($4 ~ /persistentfs/) print "/dev/"$1}' /proc/mtd | tr -d ':'`

	if [ -n "$PERSISTENTFS_DEV" ]; then
		# Create char device file if missing
		if [ ! -e $PERSISTENTFS_DEV ]; then
			echo "Creating $PERSISTENTFS_DEV ..."
			MAJOR=`cat /proc/devices | grep "\bmtd\b" | cut -b1-3`
			MINOR=`echo $PERSISTENTFS_DEV | grep -o -E "[0-9]+"`
			MINOR=`expr $MINOR \* 2`
			mknod -m 660 $PERSISTENTFS_DEV c $MAJOR $MINOR
		fi

		echo "Initializing persistent FS ..."

		# Perform format
		flash_eraseall -j $PERSISTENTFS_DEV

		# Ask for firmware reset / reboot (except Motorola, mag250)
		if [ "${DEVICEID}" != "vip19x3" -a "${DEVICEID}" != "mag250" -a "${DEVICEID}" != "mag200" ]; then
			# Reboot required
			need_reboot=1

			# Have to reset firmware version to download rootfs again to mtd with correct size
			need_reset_firmware=2
		fi
	else
		echo "No persistentfs partition found"
	fi

	fw_setenv "partitions_layout" "1"
fi

if [ "$need_reset_firmware" == "1" ]; then
	echo "will try to upgrade with same firmware or newer"
	fw_setenv restore_firmware 1
elif [ "$need_reset_firmware" == "2" ]; then
	echo "must be upgraded with same firmware or newer"
	fw_setenv restore_firmware 2
fi

echo "Quirks END ---------------------------------------------------------------------"

if [ "$need_reboot" == "1" ]; then
	if [ "${DEVICEID}" == "vip19x3" ]; then
		umount ${VIP_FFS_MOUNT}
		umount ${VIP_KERNEL_MOUNT}
	fi

	sleep 1

	reboot -f
fi
