#!/bin/sh

BLOCK_NAME=$1
BLOCK_SIZE=$2
DRYRUN=$3


ROOTFS_MOUNT_POINT="/mnt/rootfs"
PERSISTENT_SIZE_MB=16

block_device_major()
{
	local dev=$1
	local part=$2

	local F
	if [ "$part" != "" ]; then
		F=/sys/block/$dev/${dev}${part}/dev
	else
		F=/sys/block/$dev/dev
	fi

	local maj=`awk 'BEGIN {FS=":"} {print $1}' $F`
	if [ -n "$maj" ]; then
		echo $maj
	fi
}

block_device_minor()
{
        local dev=$1
	local part=$2

	local F
	if [ "$part" != "" ]; then
                F=/sys/block/$dev/${dev}${part}/dev
        else
                F=/sys/block/$dev/dev
        fi

        local min=`awk 'BEGIN {FS=":"} {print $2}' $F`
        if [ -n "$min" ]; then
                echo $min
        fi
}

BOARD=`awk '{if ($1=="machine") print $3}' /proc/cpuinfo`


case $BOARD in

    zyxel1001s|zyxel1001s2|zyxel1001h)

partitions_layout=`fw_printenv -q -n "partitions_layout"`
if [ -z "$partitions_layout" ]; then
    partitions_layout=0
fi

if [ "$BLOCK_NAME" == "kernel" -o "$BLOCK_NAME" == "backup_kernel" ]; then
	return 0
fi

if [ "$BLOCK_NAME" == "rootfs" ]; then
    ZYXEL_ROOTFS_DEVICE=`/sbin/find_zyxel_system_disk.sh`
    if [ "$?" != "0" ]; then
        unset ZYXEL_ROOTFS_DEVICE
    fi

    if [ -z "$ZYXEL_ROOTFS_DEVICE" ]; then
        echo "Error: ZyXEL system disk device not found. Can't flash rootfs !!!"
        return 1
    fi

    major=`block_device_major $ZYXEL_ROOTFS_DEVICE`
    minor=`block_device_minor $ZYXEL_ROOTFS_DEVICE`

    #
    # Prepare partitions
    #
    if [ "$DRYRUN" != "1" -a "$partitions_layout" == "0" ]; then
        mknod /dev/$ZYXEL_ROOTFS_DEVICE b $major $minor

        FLASH_SIZE_MB=`fdisk -l /dev/$ZYXEL_ROOTFS_DEVICE | awk -vDEV="$ZYXEL_ROOTFS_DEVICE" '{if ($2 == "/dev/"DEV":") print $3}'`

        echo "Flash size $FLASH_SIZE_MB MB"

        if [ "$FLASH_SIZE_MB" -lt 60 ]; then
            echo "Flash doesn't have enough size: Size $FLASH_SIZE_MB MB."
        else
            ROOTFS_SIZE_MB=`expr $FLASH_SIZE_MB \- $PERSISTENT_SIZE_MB`

            echo "Creating rootfs partition (Size $ROOTFS_SIZE_MB MB)..."
            echo -e "o\nn\np\n1\n\n+${ROOTFS_SIZE_MB}M\nw\n" | /sbin/fdisk /dev/$ZYXEL_ROOTFS_DEVICE

            if [ ! -b "/dev/${ZYXEL_ROOTFS_DEVICE}1" ]; then
                minor=`block_device_minor ${ZYXEL_ROOTFS_DEVICE} 1`
                mknod /dev/${ZYXEL_ROOTFS_DEVICE}1 b $major $minor
            fi

            if [ ! -b "/dev/${ZYXEL_ROOTFS_DEVICE}1" ]; then
                echo "error: can't create rootfs partition!"
                error=1
            else
                echo "Creating ext2 rootfs file system..."
                # Using ext2fs because it supported by busybox, and ext3fs not.
                mkfs.ext2 /dev/${ZYXEL_ROOTFS_DEVICE}1
            fi

            echo "Trying to mount rootfs partition..."

            mkdir -p $ROOTFS_MOUNT_POINT

            mount /dev/${ZYXEL_ROOTFS_DEVICE}1 $ROOTFS_MOUNT_POINT
            if [ $? != "0" ]; then
                echo "error: failed to mount rootfs partition"
                error=1
            else
                umount $ROOTFS_MOUNT_POINT
            fi

            echo "Creating persistent partition..."
            echo -e "n\np\n2\n\n\nw\n" | /sbin/fdisk /dev/${ZYXEL_ROOTFS_DEVICE}

            if [ ! -b /dev/${ZYXEL_ROOTFS_DEVICE}2 ]; then
                minor=`block_device_minor ${ZYXEL_ROOTFS_DEVICE} 2`
                mknod /dev/${ZYXEL_ROOTFS_DEVICE}2 b $major $minor
            fi

            if [ ! -b /dev/${ZYXEL_ROOTFS_DEVICE}2 ]; then
                echo "error: can't create persistent partition!"
                error=1
            else
                echo "Creating ext2 persistent file system..."
                # Using ext2fs because it supported by busybox, and ext3fs not.
                mkfs.ext2 /dev/${ZYXEL_ROOTFS_DEVICE}2
            fi

            echo "Trying to mount persistent partition..."

            mount /dev/${ZYXEL_ROOTFS_DEVICE}2 $ROOTFS_MOUNT_POINT
            if [ $? != "0" ]; then
                echo "error: failed to mount persistent partition"
                error=1
            else
                umount $ROOTFS_MOUNT_POINT
            fi

            if [ "$error" != "1" ]; then
                fw_setenv "partitions_layout" "1"
            fi
        fi
    fi

    #
    # Erase rootfs partition before update
    #
    ROOTFS_MOUNT=`mount | awk '{if ($3 == "/mnt/rootfs") print $3}' -`
    if [ "$ROOTFS_MOUNT" != "$ROOTFS_MOUNT_POINT" ]; then
        if [ ! -b /dev/${ZYXEL_ROOTFS_DEVICE}1 ]; then
            minor=`block_device_minor ${ZYXEL_ROOTFS_DEVICE} 1`
            mknod /dev/${ZYXEL_ROOTFS_DEVICE}1 b $major $minor
        fi

        if [ ! -b /dev/${ZYXEL_ROOTFS_DEVICE}1 ]; then
            echo "missing flash device /dev/${ZYXEL_ROOTFS_DEVICE}1"
            return 1;
        fi

        PART_SIZE_B=`fdisk -l /dev/${ZYXEL_ROOTFS_DEVICE}1 | awk -vDEV="$ZYXEL_ROOTFS_DEVICE" '{if ($2 == "/dev/"DEV"1:") print $5}'`

        echo "Partition size: $PART_SIZE_B Block size $BLOCK_SIZE"

        if [ $PART_SIZE_B -le $BLOCK_SIZE ]; then
            echo "error: rootfs partition size doesn't have enough size!"
            return 1
        fi

        if [ "$DRYRUN" != "1" ]; then
            mkfs.ext2 /dev/${ZYXEL_ROOTFS_DEVICE}1

            mkdir -p $ROOTFS_MOUNT_POINT

            mount /dev/${ZYXEL_ROOTFS_DEVICE}1 $ROOTFS_MOUNT_POINT
            if [ $? != "0" ]; then
                echo "error: failed to mount flash /dev/${ZYXEL_ROOTFS_DEVICE}1"
                return 1
            fi
        fi
    fi
fi
	;;

esac

return 0
