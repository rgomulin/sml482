#!/bin/sh

#
# Updates variable value only if current differs from new one
#
set_if_changed() {
    tmp=`fw_printenv -n "$1" 2>/dev/null`
    if [ "$tmp" != "$2" ]; then
        fw_setenv "$1" "$2"
        echo "Replacing value of \"$1\""
        echo "   after  : $tmp"
        echo "   before : $2"
    fi
}

. /etc/init.d/init-functions

get_deviceid

echo "Running post-upgrade script ..."

ROOTFS_MOUNT_POINT="/mnt/rootfs"

# current firmware version
FIRMWARE_VERSION=`fw_printenv -q -n "firmware_version"`
# NAND flash partition layout
partitions_layout=`fw_printenv -n "partitions_layout"`

case ${DEVICEID} in
    mag250)
        echo "SmartLabs software is flashed into MAG250"

        #
        # U-boot variables are being tuned only if SmartLabs software was successfully
        # flashed to NAND of MAG250.
        #
        SERIAL=`fw_printenv -q -n serial#`
        if [ -z "$SERIAL" ]; then
            SERIAL=`/sbin/stbvendor --serial`
            if [ -z "$SERIAL" ]; then
                echo "Error: failed to get serial number"
            else
                fw_setenv serial# "$SERIAL"
            fi
        fi

        set_if_changed addmisc 'setenv bootargs'
        set_if_changed flash_self 'run addmisc; mtdparts default; setenv partition nand0,0 ;fsload ${kernel}; bootm; run flash_self2'
        set_if_changed flash_self2 'run addmisc; mtdparts default; setenv partition nand0,2 ;fsload ${kernel}; bootm; run net'
        set_if_changed bootcmd 'run flash_self'
        ;;

    mag200)
        set_if_changed mtdids 'nand0=nand'
        set_if_changed partition 'nand0,0'
        set_if_changed mtdparts 'mtdparts=nand:4M(kernel),4M(backup_kernel),-(reserved)'

        set_if_changed addmisc 'setenv bootargs'
        set_if_changed flash_self 'run addmisc; setenv partition nand0,0 ;fsload ${kernel}; bootm; run flash_self2'
        set_if_changed flash_self2 'run addmisc; setenv partition nand0,1 ;fsload ${kernel}; bootm; run net'

        set_if_changed bootcmd 'run flash_self'

        # mag200 stores logo at the beginning of /dev/mtd3,
        # and u-boot environment starts at 0xC000 offset in same mtd device
        if [ -f "/tmp/infomir_logo.img" ]; then
            ENV_DEVICE=`awk '{if ($4 ~ /env/) print $1}' /proc/mtd | sed 's/\(.*\):/\/dev\/\1/g'`
            if [ -n "$ENV_DEVICE" ]; then
                # NOTE: DO NOT run fw_setenv while executing this code
                dd if=$ENV_DEVICE of=/tmp/env.img
                dd if=/tmp/infomir_logo.img bs=4096 count=12 of=/tmp/env.img seek=0 conv=notrunc
                flashcp /tmp/env.img $ENV_DEVICE
            fi
        fi
        ;;

    zyxel1001s|zyxel1001s2|zyxel1001h)
        ROOTFS_MOUNT=`mount | awk '{if ($3 == "/mnt/rootfs") print $3}' -`
        if [ "$ROOTFS_MOUNT" == "$ROOTFS_MOUNT_POINT" ]; then
            echo "Unmounting $ROOTFS_MOUNT_POINT. Please, wait ..."
            umount $ROOTFS_MOUNT_POINT
        fi
        ;;
esac
