#!/bin/sh

##### Includes

# Source function library
. /etc/init.d/init-functions

##### Entry point

# Read device id
get_deviceid

NVRAM_DEV=`awk '{if ($4 ~ /"nvram"/) print $1}' /proc/mtd | sed 's/://g'`

if [ -z "$NVRAM_DEV" ]; then
    echo "$0: nvram device not found" >&2
    exit 1
fi

NVRAM_OFFSET=0
case $DEVICEID in
    yuxing)
        NVRAM_OFFSET=160
        ;;
esac


if [ -z "$1" ]; then
    # no arguments -> show contents
    cfe_env "/dev/$NVRAM_DEV" -l -o ${NVRAM_OFFSET}
    exit $?
fi

if [ -z "$2" ]; then
    # read argument
    NAME=$1
    cfe_env "/dev/$NVRAM_DEV" -l -o ${NVRAM_OFFSET} | sed "/^$NAME=/!d; s///;q"
    exit $?
fi

exit 0
